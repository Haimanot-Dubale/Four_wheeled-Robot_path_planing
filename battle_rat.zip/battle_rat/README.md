# innok_heros_description
ROS Package with URDF files and launch files for Innok Heros

for more information see http://wiki.ros.org/innok_heros_description
