^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package innok_heros_description
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.3 (2016-03-10)
------------------
* added missing run_depend
* added joint_state_publisher to get correct tf when launching RViz
* Contributors: Sabrina Heerklotz

1.0.2 (2015-12-11)
------------------
* Fixed CMakeLists.txt
* Contributors: Sabrina Heerklotz

1.0.1 (2015-10-20)
------------------
* fixed dependencies
* Contributors: Sabrina Heerklotz

1.0.0 (2015-10-15)
------------------
* initial commit
* Contributors: Sabrina Heerklotz, Jonathan Hechtbauer
